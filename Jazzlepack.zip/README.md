# Jazzlepack
Minecraft resourcepack made with stuff that includes stuff in it
All credits to original creator, JazzleMcDazzle
